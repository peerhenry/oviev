to create the executable, run:

pyinstaller main.py

This will generate the bundle in a subdirectory called dist.